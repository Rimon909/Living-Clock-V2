# Living Clock

Cinematic live wallpaper: your photo, a clock behind you, a comet around your outline.
Push to main; GitHub Actions builds the debug APK.
