package com.rimon.livingclock;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.service.wallpaper.WallpaperService;
import android.view.Choreographer;
import android.view.SurfaceHolder;

/**
 * Battery-first live wallpaper.
 *
 * - Nothing runs while the wallpaper is hidden or the screen is off.
 * - There are no sensors at all.
 * - Frames follow display vsync and are throttled to 60, 30 or 1 per second.
 * - ECO wakes once per second and sleeps in between, apart from the short focus pull each minute.
 * - Android battery saver, or a battery at 15% or lower, forces ECO automatically.
 * - Heavy work (decoding, blurring, silhouette tracing) happens once, off the UI thread.
 */
public class LivingClockService extends WallpaperService {

    private static final IntentFilter BATTERY_FILTER = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);

    @Override
    public Engine onCreateEngine() {
        return new ClockEngine();
    }

    private final class ClockEngine extends Engine
            implements SharedPreferences.OnSharedPreferenceChangeListener {

        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Choreographer choreographer = Choreographer.getInstance();
        private final ClockRenderer renderer = new ClockRenderer();
        private final Choreographer.FrameCallback frameCallback = this::onVsync;
        private final Runnable requestFrameTask = this::requestFrame;

        private SharedPreferences prefs;
        private Scene scene;

        private boolean visible;
        private boolean surfaceReady;
        private boolean destroyed;
        private boolean framePending;
        private boolean powerSave;
        private boolean charging;
        private int battery = 100;
        private int userMode = Settings.MODE_BALANCED;
        private int width;
        private int height;
        private int generation;
        private long lastDrawNanos;
        private long lastPollMs;

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            prefs = Settings.prefs(LivingClockService.this);
            prefs.registerOnSharedPreferenceChangeListener(this);
            readSettings();
        }

        @Override
        public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            if (visible) {
                lastDrawNanos = 0L;
                lastPollMs = 0L;
                readSettings();
                requestFrame();
            } else {
                stopScheduling();
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int w, int h) {
            super.onSurfaceChanged(holder, format, w, h);
            boolean sizeChanged = w != width || h != height;
            width = w;
            height = h;
            surfaceReady = w > 0 && h > 0;
            if (surfaceReady && sizeChanged) {
                renderer.setSize(w, h);
                if (scene != null) {
                    scene.recycle();
                    scene = null;
                }
                reloadScene();
            }
            requestFrame();
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            surfaceReady = false;
            stopScheduling();
            super.onSurfaceDestroyed(holder);
        }

        @Override
        public void onDestroy() {
            destroyed = true;
            generation++;
            stopScheduling();
            if (prefs != null) {
                prefs.unregisterOnSharedPreferenceChangeListener(this);
            }
            renderer.release();
            if (scene != null) {
                scene.recycle();
                scene = null;
            }
            super.onDestroy();
        }

        @Override
        public void onSharedPreferenceChanged(SharedPreferences p, String key) {
            if (Settings.KEY_SCENE.equals(key)) {
                reloadScene();
            } else {
                readSettings();
                requestFrame();
            }
        }

        // ---------- settings and scene ----------

        private void readSettings() {
            userMode = prefs.getInt(Settings.KEY_MODE, Settings.MODE_BALANCED);
            renderer.setOptions(
                    prefs.getInt(Settings.KEY_FX, Settings.FX_ALL),
                    prefs.getInt(Settings.KEY_SIZE, 100),
                    prefs.getFloat(Settings.KEY_X, -1f),
                    prefs.getFloat(Settings.KEY_Y, -1f));
        }

        private void reloadScene() {
            if (!surfaceReady || destroyed) {
                return;
            }
            final int gen = ++generation;
            Scene.buildAsync(LivingClockService.this, width, height, built -> {
                if (destroyed || gen != generation) {
                    built.recycle();
                    return;
                }
                Scene old = scene;
                scene = built;
                renderer.setScene(built);
                if (old != null) {
                    old.recycle();
                }
                requestFrame();
            });
        }

        /** Reads battery level and power-saver state at most every 30 seconds. */
        private void pollSystem(long nowMs) {
            if (lastPollMs != 0L && nowMs - lastPollMs < 30_000L) {
                return;
            }
            lastPollMs = nowMs;
            Intent i = LivingClockService.this.registerReceiver(null, BATTERY_FILTER);
            if (i != null) {
                int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                int status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                        || status == BatteryManager.BATTERY_STATUS_FULL;
                if (level >= 0 && scale > 0) {
                    battery = level * 100 / scale;
                    renderer.setBattery(battery);
                }
            }
            PowerManager pm = (PowerManager) LivingClockService.this.getSystemService(Context.POWER_SERVICE);
            powerSave = pm != null && pm.isPowerSaveMode();
        }

        private int effectiveMode() {
            if (powerSave || (battery <= 15 && !charging)) {
                return Settings.MODE_ECO;
            }
            return userMode;
        }

        // ---------- frame scheduling ----------

        private boolean canRender() {
            return !destroyed && visible && surfaceReady;
        }

        private void requestFrame() {
            if (framePending || !canRender()) {
                return;
            }
            framePending = true;
            choreographer.postFrameCallback(frameCallback);
        }

        private void onVsync(long frameNanos) {
            framePending = false;
            if (!canRender()) {
                return;
            }
            long now = System.currentTimeMillis();
            pollSystem(now);
            int mode = effectiveMode();
            int fps = renderer.targetFps(now, mode);

            if (fps > 1) {
                long interval = 1_000_000_000L / fps;
                if (lastDrawNanos != 0L && frameNanos - lastDrawNanos < interval * 9L / 10L) {
                    requestFrame(); // too early for this frame rate: wait for the next vsync
                    return;
                }
            }
            lastDrawNanos = frameNanos;
            drawFrame(now, mode != Settings.MODE_ECO);

            long after = System.currentTimeMillis();
            if (renderer.targetFps(after, mode) > 1) {
                requestFrame();
            } else {
                // ECO and idle: sleep until just after the next whole second.
                handler.postDelayed(requestFrameTask, 1000L - (after % 1000L) + 4L);
            }
        }

        private void stopScheduling() {
            framePending = false;
            handler.removeCallbacks(requestFrameTask);
            choreographer.removeFrameCallback(frameCallback);
        }

        // ---------- drawing ----------

        private void drawFrame(long nowMs, boolean sweep) {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    canvas = holder.lockHardwareCanvas();
                }
                if (canvas == null) {
                    canvas = holder.lockCanvas();
                }
                if (canvas != null) {
                    renderer.draw(canvas, nowMs, sweep);
                }
            } catch (RuntimeException ignored) {
                // The surface can vanish mid-frame during rotation or lock-screen changes.
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas);
                    } catch (RuntimeException ignored) {
                        // Surface no longer valid.
                    }
                }
            }
        }
    }
}
