package com.rimon.livingclock;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;

import java.io.File;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Everything the renderer needs for one screen size, prepared once off the UI thread:
 * fitted photo, blurred copy, subject cutout, soft shadow, comet track and the clock's best spot.
 * The renderer only blits these, so frames stay cheap.
 */
final class Scene {

    interface Callback {
        void onScene(Scene scene);
    }

    private static final ExecutorService POOL = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    final int width;
    final int height;

    Bitmap background;      // photo fitted to the screen
    Bitmap backgroundBlur;  // small blurred copy, used by the focus pull
    Bitmap cutout;          // photo multiplied by the person mask
    Bitmap shadow;          // small blurred silhouette, black
    int cell = 6;           // screen pixels per grid cell (also the shadow bitmap scale)
    float shadowPivotX;
    float shadowPivotY;
    float[] segs;           // visible silhouette segments: x0, y0, x1, y1 ...
    int segCount;
    float autoX;
    float autoY;
    float autoR;
    float[] eyes;           // x1, y1, x2, y2, lens radius, in screen pixels

    private boolean placed;

    private Scene(int w, int h) {
        width = w;
        height = h;
    }

    static void buildAsync(Context context, int w, int h, Callback callback) {
        Context app = context.getApplicationContext();
        POOL.execute(() -> {
            Scene scene = build(app, w, h);
            MAIN.post(() -> callback.onScene(scene));
        });
    }

    void recycle() {
        recycle(background);
        recycle(backgroundBlur);
        recycle(cutout);
        recycle(shadow);
        background = null;
        backgroundBlur = null;
        cutout = null;
        shadow = null;
        segs = null;
        segCount = 0;
    }

    private static void recycle(Bitmap b) {
        if (b != null && !b.isRecycled()) {
            b.recycle();
        }
    }

    // ---------- build ----------

    private static Scene build(Context app, int w, int h) {
        Scene s = new Scene(w, h);
        try {
            s.load(app);
        } catch (OutOfMemoryError e) {
            s.recycle();
            s = new Scene(w, h);
        }
        if (!s.placed) {
            s.placeAuto(null);
        }
        return s;
    }

    private void load(Context app) {
        File photoFile = new File(app.getFilesDir(), LayerLoader.PHOTO_FILE);
        if (width <= 0 || height <= 0 || !photoFile.exists()) {
            return;
        }
        Bitmap photo = decode(photoFile);
        if (photo == null) {
            return;
        }

        float pw = photo.getWidth();
        float ph = photo.getHeight();
        float s = Math.max(width / pw, height / ph);
        RectF dst = new RectF((width - pw * s) / 2f, (height - ph * s) / 2f,
                (width + pw * s) / 2f, (height + ph * s) / 2f);

        background = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        new Canvas(background).drawBitmap(photo, null, dst, new Paint(Paint.FILTER_BITMAP_FLAG));
        photo.recycle();
        backgroundBlur = blurred(background);

        File maskFile = new File(app.getFilesDir(), LayerLoader.MASK_FILE);
        Bitmap mask = maskFile.exists() ? BitmapFactory.decodeFile(maskFile.getAbsolutePath()) : null;
        if (mask != null) {
            cutout = background.copy(Bitmap.Config.ARGB_8888, true);
            if (cutout != null) {
                Paint dstIn = new Paint(Paint.FILTER_BITMAP_FLAG);
                dstIn.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
                new Canvas(cutout).drawBitmap(mask, null, dst, dstIn);
            }
            mask.recycle();
            if (cutout != null) {
                analyse();
            }
        }

        String e = Settings.prefs(app).getString(Settings.KEY_EYES, "");
        if (e != null && !e.isEmpty()) {
            try {
                String[] p = e.split(",");
                if (p.length == 5) {
                    float[] v = new float[5];
                    for (int i = 0; i < 5; i++) {
                        v[i] = Float.parseFloat(p[i]);
                    }
                    eyes = new float[]{
                            dst.left + v[0] * dst.width(), dst.top + v[1] * dst.height(),
                            dst.left + v[2] * dst.width(), dst.top + v[3] * dst.height(),
                            v[4] * dst.width()};
                }
            } catch (NumberFormatException ignored) {
                eyes = null;
            }
        }
    }

    /** Decodes the photo at a size that still covers the screen. */
    private Bitmap decode(File file) {
        String path = file.getAbsolutePath();
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            return null;
        }
        float need = Math.max(width / (float) bounds.outWidth, height / (float) bounds.outHeight);
        int sample = 1;
        while (need * sample * 2f <= 1f) {
            sample *= 2;
        }
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inSampleSize = sample;
        o.inPreferredConfig = Bitmap.Config.ARGB_8888;
        return BitmapFactory.decodeFile(path, o);
    }

    // ---------- silhouette analysis ----------

    private void analyse() {
        cell = Math.max(4, Math.round(width / 180f));
        int gw = (width + cell - 1) / cell;
        int gh = (height + cell - 1) / cell;
        int n = gw * gh;

        Bitmap g = downscale(cutout, gw, gh);
        int[] px = new int[n];
        g.getPixels(px, 0, gw, 0, 0, gw, gh);
        if (g != cutout) {
            g.recycle();
        }

        int[] alpha = new int[n];
        boolean[] fg = new boolean[n];
        for (int i = 0; i < n; i++) {
            alpha[i] = px[i] >>> 24;
            fg[i] = alpha[i] > 127;
        }

        boolean[] keep = largest(fg, gw, gh);
        if (keep == null) {
            return;
        }
        buildShadow(alpha, keep, gw, gh);
        placeAuto(distance(keep, gw, gh));
        buildContour(keep, gw, gh);
    }

    /** Keeps only the largest connected blob so stray specks never steer the layout. */
    private static boolean[] largest(boolean[] fg, int gw, int gh) {
        int n = gw * gh;
        int[] label = new int[n];
        int[] queue = new int[n];
        int best = 0;
        int bestSize = 0;
        int id = 0;
        for (int i = 0; i < n; i++) {
            if (!fg[i] || label[i] != 0) {
                continue;
            }
            id++;
            int head = 0;
            int tail = 0;
            queue[tail++] = i;
            label[i] = id;
            while (head < tail) {
                int p = queue[head++];
                int x = p % gw;
                int y = p / gw;
                if (x > 0 && fg[p - 1] && label[p - 1] == 0) {
                    label[p - 1] = id;
                    queue[tail++] = p - 1;
                }
                if (x < gw - 1 && fg[p + 1] && label[p + 1] == 0) {
                    label[p + 1] = id;
                    queue[tail++] = p + 1;
                }
                if (y > 0 && fg[p - gw] && label[p - gw] == 0) {
                    label[p - gw] = id;
                    queue[tail++] = p - gw;
                }
                if (y < gh - 1 && fg[p + gw] && label[p + gw] == 0) {
                    label[p + gw] = id;
                    queue[tail++] = p + gw;
                }
            }
            if (tail > bestSize) {
                bestSize = tail;
                best = id;
            }
        }
        if (bestSize < n / 200) {
            return null;
        }
        boolean[] keep = new boolean[n];
        for (int i = 0; i < n; i++) {
            keep[i] = label[i] == best;
        }
        return keep;
    }

    private void buildShadow(int[] alpha, boolean[] keep, int gw, int gh) {
        int n = gw * gh;
        int[] px = new int[n];
        for (int i = 0; i < n; i++) {
            int a = keep[i] ? alpha[i] : 0;
            px[i] = 0xFF000000 | (a << 16) | (a << 8) | a;
        }
        boxBlur(px, gw, gh, 3);
        boxBlur(px, gw, gh, 3);
        for (int i = 0; i < n; i++) {
            px[i] = (px[i] & 0xFF) << 24;
        }
        shadow = Bitmap.createBitmap(gw, gh, Bitmap.Config.ARGB_8888);
        shadow.setPixels(px, 0, gw, 0, 0, gw, gh);

        // The shadow swings from the subject's feet (or the bottom edge of the frame).
        int maxY = 0;
        for (int i = n - 1; i >= 0; i--) {
            if (keep[i]) {
                maxY = i / gw;
                break;
            }
        }
        float sum = 0f;
        int count = 0;
        for (int y = Math.max(0, maxY - 2); y <= maxY; y++) {
            for (int x = 0; x < gw; x++) {
                if (keep[y * gw + x]) {
                    sum += x;
                    count++;
                }
            }
        }
        shadowPivotX = (count > 0 ? sum / count : gw / 2f) * cell + cell / 2f;
        shadowPivotY = (maxY + 1) * cell;
    }

    /** Distance, in grid cells, from every cell to the nearest subject cell. */
    private static float[] distance(boolean[] keep, int gw, int gh) {
        int n = gw * gh;
        float[] d = new float[n];
        final float diag = 1.414f;
        for (int i = 0; i < n; i++) {
            d[i] = keep[i] ? 0f : 1e9f;
        }
        for (int y = 0; y < gh; y++) {
            for (int x = 0; x < gw; x++) {
                int i = y * gw + x;
                float v = d[i];
                if (x > 0) {
                    v = Math.min(v, d[i - 1] + 1f);
                }
                if (y > 0) {
                    v = Math.min(v, d[i - gw] + 1f);
                    if (x > 0) {
                        v = Math.min(v, d[i - gw - 1] + diag);
                    }
                    if (x < gw - 1) {
                        v = Math.min(v, d[i - gw + 1] + diag);
                    }
                }
                d[i] = v;
            }
        }
        for (int y = gh - 1; y >= 0; y--) {
            for (int x = gw - 1; x >= 0; x--) {
                int i = y * gw + x;
                float v = d[i];
                if (x < gw - 1) {
                    v = Math.min(v, d[i + 1] + 1f);
                }
                if (y < gh - 1) {
                    v = Math.min(v, d[i + gw] + 1f);
                    if (x < gw - 1) {
                        v = Math.min(v, d[i + gw + 1] + diag);
                    }
                    if (x > 0) {
                        v = Math.min(v, d[i + gw - 1] + diag);
                    }
                }
                d[i] = v;
            }
        }
        return d;
    }

    /**
     * Finds the biggest empty circle in the upper part of the screen and sizes the clock to it.
     * The ring is a little larger than the gap, so the subject overlaps it and hides part of it.
     */
    private void placeAuto(float[] dist) {
        placed = true;
        int gw = (width + cell - 1) / cell;
        int gh = (height + cell - 1) / cell;
        float m = width * 0.03f;
        float top = height * 0.07f;
        float bx = width / 2f;
        float by = height * 0.34f;
        float bestFree = 0f;
        float bestScore = -1e9f;

        for (int y = 0; y < gh; y++) {
            float cy = (y + 0.5f) * cell;
            if (cy > height * 0.62f) {
                break;
            }
            for (int x = 0; x < gw; x++) {
                float cx = (x + 0.5f) * cell;
                float free = Math.min(Math.min(cx - m, width - cx - m), cy - top);
                if (dist != null) {
                    free = Math.min(free, dist[y * gw + x] * cell);
                }
                float score = free - 0.05f * Math.abs(cx - width / 2f)
                        - 0.05f * Math.abs(cy - height * 0.34f);
                if (score > bestScore) {
                    bestScore = score;
                    bestFree = free;
                    bx = cx;
                    by = cy;
                }
            }
        }
        float r = Math.max(width * 0.17f, Math.min(width * 0.34f, bestFree * 1.35f));
        autoR = r;
        autoX = Math.max(r + m, Math.min(width - r - m, bx));
        autoY = Math.max(r + top * 0.7f, Math.min(height * 0.7f, by));
    }

    /**
     * Traces the outer edge of the subject (Moore-neighbour walk), smooths it, resamples it to
     * even spacing and keeps only the parts that are not hidden against the screen border.
     * The result is the track the comet runs along.
     */
    private void buildContour(boolean[] keep, int gw, int gh) {
        int start = -1;
        for (int i = 0; i < keep.length; i++) {
            if (keep[i]) {
                start = i;
                break;
            }
        }
        if (start < 0) {
            return;
        }
        final int[] dx = {-1, -1, 0, 1, 1, 1, 0, -1};
        final int[] dy = {0, -1, -1, -1, 0, 1, 1, 1};

        int sx = start % gw;
        int sy = start / gw;
        int cap = 2048;
        int[] pts = new int[cap * 2];
        int count = 0;
        int cx = sx;
        int cy = sy;
        int bd = 0; // the pixel west of the start is always background
        int limit = gw * gh * 4;

        for (int step = 0; step < limit; step++) {
            if (count == cap) {
                cap *= 2;
                pts = Arrays.copyOf(pts, cap * 2);
            }
            pts[count * 2] = cx;
            pts[count * 2 + 1] = cy;
            count++;

            int prevX = cx + dx[bd];
            int prevY = cy + dy[bd];
            int nx = 0;
            int ny = 0;
            boolean found = false;
            for (int k = 1; k <= 8; k++) {
                int d = (bd + k) & 7;
                int tx = cx + dx[d];
                int ty = cy + dy[d];
                if (tx >= 0 && ty >= 0 && tx < gw && ty < gh && keep[ty * gw + tx]) {
                    nx = tx;
                    ny = ty;
                    found = true;
                    break;
                }
                prevX = tx;
                prevY = ty;
            }
            if (!found) {
                break;
            }
            int ddx = prevX - nx;
            int ddy = prevY - ny;
            int nb = 0;
            for (int d = 0; d < 8; d++) {
                if (dx[d] == ddx && dy[d] == ddy) {
                    nb = d;
                    break;
                }
            }
            cx = nx;
            cy = ny;
            bd = nb;
            if (cx == sx && cy == sy) {
                break;
            }
        }
        if (count < 24) {
            return;
        }

        int n = count;
        float[] fx = new float[n];
        float[] fy = new float[n];
        for (int i = 0; i < n; i++) {
            fx[i] = (pts[i * 2] + 0.5f) * cell;
            fy[i] = (pts[i * 2 + 1] + 0.5f) * cell;
        }
        for (int pass = 0; pass < 3; pass++) {
            smooth(fx, n);
            smooth(fy, n);
        }

        float[] cum = new float[n + 1];
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            cum[i + 1] = cum[i] + (float) Math.hypot(fx[j] - fx[i], fy[j] - fy[i]);
        }
        float total = cum[n];
        float spacing = Math.max(2f, width * 0.0025f);
        int m = Math.max(24, (int) (total / spacing));
        float[] rx = new float[m];
        float[] ry = new float[m];
        int seg = 0;
        for (int k = 0; k < m; k++) {
            float target = total * k / m;
            while (seg < n - 1 && cum[seg + 1] < target) {
                seg++;
            }
            float len = cum[seg + 1] - cum[seg];
            float t = len > 0f ? (target - cum[seg]) / len : 0f;
            int j = (seg + 1) % n;
            rx[k] = fx[seg] + (fx[j] - fx[seg]) * t;
            ry[k] = fy[seg] + (fy[j] - fy[seg]) * t;
        }

        float edge = cell * 1.5f;
        float[] out = new float[m * 4];
        int c = 0;
        for (int k = 0; k < m; k++) {
            int j = (k + 1) % m;
            if (onScreen(rx[k], ry[k], edge) && onScreen(rx[j], ry[j], edge)) {
                out[c++] = rx[k];
                out[c++] = ry[k];
                out[c++] = rx[j];
                out[c++] = ry[j];
            }
        }
        segs = Arrays.copyOf(out, c);
        segCount = c / 4;
    }

    private boolean onScreen(float x, float y, float edge) {
        return x > edge && y > edge && x < width - edge && y < height - edge;
    }

    private static void smooth(float[] a, int n) {
        float[] t = new float[n];
        for (int i = 0; i < n; i++) {
            float s = 0f;
            for (int k = -2; k <= 2; k++) {
                s += a[(i + k + n) % n];
            }
            t[i] = s / 5f;
        }
        System.arraycopy(t, 0, a, 0, n);
    }

    // ---------- bitmap helpers ----------

    private static Bitmap blurred(Bitmap src) {
        int bw = Math.max(8, src.getWidth() / 8);
        int bh = Math.max(8, src.getHeight() / 8);
        Bitmap small = downscale(src, bw, bh);
        int[] px = new int[bw * bh];
        small.getPixels(px, 0, bw, 0, 0, bw, bh);
        if (small != src) {
            small.recycle();
        }
        boxBlur(px, bw, bh, 3);
        boxBlur(px, bw, bh, 3);
        Bitmap out = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
        out.setPixels(px, 0, bw, 0, 0, bw, bh);
        return out;
    }

    /** Halves repeatedly before the final resize, which avoids the aliasing of one big step. */
    private static Bitmap downscale(Bitmap src, int tw, int th) {
        Bitmap cur = src;
        while (cur.getWidth() >= tw * 2 && cur.getHeight() >= th * 2) {
            Bitmap next = Bitmap.createScaledBitmap(cur, cur.getWidth() / 2, cur.getHeight() / 2, true);
            if (cur != src) {
                cur.recycle();
            }
            cur = next;
        }
        Bitmap fin = Bitmap.createScaledBitmap(cur, tw, th, true);
        if (cur != src && cur != fin) {
            cur.recycle();
        }
        return fin;
    }

    private static void boxBlur(int[] px, int w, int h, int r) {
        int[] tmp = new int[px.length];
        blurPass(px, tmp, w, h, r, true);
        blurPass(tmp, px, w, h, r, false);
    }

    private static void blurPass(int[] src, int[] dst, int w, int h, int r, boolean horizontal) {
        int lines = horizontal ? h : w;
        int len = horizontal ? w : h;
        int stride = horizontal ? 1 : w;
        int lineStep = horizontal ? w : 1;
        int div = 2 * r + 1;
        for (int l = 0; l < lines; l++) {
            int base = l * lineStep;
            int sr = 0;
            int sg = 0;
            int sb = 0;
            for (int i = -r; i <= r; i++) {
                int p = src[base + clamp(i, len) * stride];
                sr += (p >> 16) & 0xFF;
                sg += (p >> 8) & 0xFF;
                sb += p & 0xFF;
            }
            for (int i = 0; i < len; i++) {
                dst[base + i * stride] = 0xFF000000 | ((sr / div) << 16) | ((sg / div) << 8) | (sb / div);
                int add = src[base + clamp(i + r + 1, len) * stride];
                int sub = src[base + clamp(i - r, len) * stride];
                sr += ((add >> 16) & 0xFF) - ((sub >> 16) & 0xFF);
                sg += ((add >> 8) & 0xFF) - ((sub >> 8) & 0xFF);
                sb += (add & 0xFF) - (sub & 0xFF);
            }
        }
    }

    private static int clamp(int i, int len) {
        return i < 0 ? 0 : (i >= len ? len - 1 : i);
    }
}
