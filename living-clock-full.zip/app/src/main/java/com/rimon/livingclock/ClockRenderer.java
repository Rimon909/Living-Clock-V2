package com.rimon.livingclock;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

import java.util.TimeZone;

/**
 * Draws one frame, back to front:
 * photo, focus pull, sun shadow, clock ring and hands, subject cutout, comet, lens clocks.
 * The cutout is drawn over the clock, so the clock appears to sit behind the person.
 * Nothing is allocated per frame. Heavy assets come prepared from Scene.
 */
public final class ClockRenderer {

    private static final int TICKS = 60;
    private static final int TRAIL = 14;
    private static final int RED = Color.rgb(232, 40, 56);
    private static final int BG_FALLBACK = Color.rgb(10, 14, 22);

    private static final float[] COS = new float[TICKS];
    private static final float[] SIN = new float[TICKS];
    private static final float[] LENS_TICKS = new float[48];

    static {
        for (int i = 0; i < TICKS; i++) {
            double a = Math.toRadians(i * 6.0 - 90.0);
            COS[i] = (float) Math.cos(a);
            SIN[i] = (float) Math.sin(a);
        }
        for (int i = 0; i < 12; i++) {
            double a = Math.toRadians(i * 30.0 - 90.0);
            float cos = (float) Math.cos(a);
            float sin = (float) Math.sin(a);
            LENS_TICKS[i * 4] = cos * 0.78f;
            LENS_TICKS[i * 4 + 1] = sin * 0.78f;
            LENS_TICKS[i * 4 + 2] = cos * 0.92f;
            LENS_TICKS[i * 4 + 3] = sin * 0.92f;
        }
    }

    private final Paint bitmapPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint outline = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Matrix matrix = new Matrix();
    private final RectF rect = new RectF();
    private final Path hourPath = new Path();
    private final Path minutePath = new Path();
    private final boolean[] tickDark = new boolean[TICKS];

    private Scene scene;
    private int width;
    private int height;
    private int fx = Settings.FX_ALL;
    private int sizePercent = 100;
    private float manualX = -1f;
    private float manualY = -1f;
    private int batteryPct = 100;

    private boolean layoutDirty = true;
    private boolean ringDirty = true;
    private float cx;
    private float cy;
    private float radius;
    private boolean handsDark;
    private Bitmap ring;

    private TimeZone zone = TimeZone.getDefault();
    private long zoneCheckMs;
    private int hour;
    private int minute;
    private int sec;
    private int ms;

    public ClockRenderer() {
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        fill.setStyle(Paint.Style.FILL);
        outline.setStyle(Paint.Style.STROKE);
        outline.setStrokeJoin(Paint.Join.ROUND);
    }

    // ---------- configuration ----------

    public void setSize(int w, int h) {
        if (w == width && h == height) {
            return;
        }
        width = w;
        height = h;
        scene = null;
        layoutDirty = true;
    }

    /** The scene is ignored if it was built for a different size. The caller owns and recycles it. */
    void setScene(Scene s) {
        scene = (s != null && s.width == width && s.height == height) ? s : null;
        layoutDirty = true;
    }

    public void setOptions(int effects, int size, float manX, float manY) {
        if (((effects ^ fx) & Settings.FX_BATTERY) != 0) {
            ringDirty = true;
        }
        fx = effects;
        if (size != sizePercent || manX != manualX || manY != manualY) {
            sizePercent = size;
            manualX = manX;
            manualY = manY;
            layoutDirty = true;
        }
    }

    public void setBattery(int percent) {
        int p = Math.max(0, Math.min(100, percent));
        if (p != batteryPct) {
            batteryPct = p;
            if ((fx & Settings.FX_BATTERY) != 0) {
                ringDirty = true;
            }
        }
    }

    public void release() {
        if (ring != null) {
            ring.recycle();
            ring = null;
        }
        scene = null;
    }

    // ---------- pacing ----------

    /**
     * Frames per second this moment needs: 60, 30 or 1.
     * ECO sleeps between seconds but wakes up for the short focus-pull animation.
     */
    public int targetFps(long nowMs, int mode) {
        if (mode == Settings.MODE_ULTRA) {
            return 60;
        }
        if (mode == Settings.MODE_BALANCED) {
            return 30;
        }
        return eventActive(nowMs) ? 30 : 1;
    }

    private boolean eventActive(long nowMs) {
        if ((fx & Settings.FX_FOCUS) == 0 || scene == null || scene.backgroundBlur == null) {
            return false;
        }
        updateTime(nowMs);
        return sec * 1000 + ms < (minute == 0 ? 5200 : 2600);
    }

    private void updateTime(long nowMs) {
        if (nowMs - zoneCheckMs > 60_000L || nowMs < zoneCheckMs) {
            zone = TimeZone.getDefault();
            zoneCheckMs = nowMs;
        }
        long local = nowMs + zone.getOffset(nowMs);
        long day = local % 86_400_000L;
        if (day < 0L) {
            day += 86_400_000L;
        }
        hour = (int) (day / 3_600_000L);
        minute = (int) ((day / 60_000L) % 60L);
        sec = (int) ((day / 1000L) % 60L);
        ms = (int) (day % 1000L);
    }

    // ---------- drawing ----------

    public void draw(Canvas c, long nowMs, boolean sweep) {
        if (width <= 0 || height <= 0) {
            return;
        }
        updateTime(nowMs);
        if (layoutDirty) {
            layout();
        }
        Scene s = scene;

        // 1. Photo.
        if (s != null && s.background != null) {
            c.drawBitmap(s.background, 0f, 0f, bitmapPaint);
        } else {
            c.drawColor(BG_FALLBACK);
        }

        // 2. Focus pull: the background softens for a moment each minute, longer each hour.
        if (s != null && s.backgroundBlur != null && (fx & Settings.FX_FOCUS) != 0) {
            float focus = focusAmount();
            if (focus > 0.002f) {
                rect.set(0f, 0f, width, height);
                bitmapPaint.setAlpha((int) (focus * 255f));
                c.drawBitmap(s.backgroundBlur, null, rect, bitmapPaint);
                bitmapPaint.setAlpha(255);
                if (minute == 0) {
                    fill.setColor(Color.argb((int) (focus * 70f), 0, 0, 0));
                    c.drawRect(0f, 0f, width, height, fill);
                }
            }
        }

        // 3. Sun shadow.
        if (s != null && s.shadow != null && (fx & Settings.FX_SHADOW) != 0) {
            drawShadow(c, s);
        }

        // 4. Clock.
        drawClock(c, sweep);

        // 5. Subject, in front of the clock.
        if (s != null && s.cutout != null) {
            c.drawBitmap(s.cutout, 0f, 0f, bitmapPaint);
        }

        // 6. Comet around the silhouette.
        if (s != null && s.segs != null && (fx & Settings.FX_COMET) != 0) {
            drawComet(c, s);
        }

        // 7. Tiny clocks in the lenses.
        if (s != null && s.eyes != null && (fx & Settings.FX_LENS) != 0) {
            drawLens(c, s.eyes, sweep);
        }
    }

    private static float smooth(float x) {
        x = x < 0f ? 0f : (x > 1f ? 1f : x);
        return x * x * (3f - 2f * x);
    }

    private float focusAmount() {
        boolean hourEvent = minute == 0;
        float t = sec * 1000f + ms;
        float total = hourEvent ? 5200f : 2600f;
        if (t >= total) {
            return 0f;
        }
        float peak = hourEvent ? 900f : 450f;
        float hold = hourEvent ? 500f : 120f;
        if (t < peak) {
            return smooth(t / peak);
        }
        if (t < peak + hold) {
            return 1f;
        }
        return 1f - smooth((t - peak - hold) / (total - peak - hold));
    }

    private void drawShadow(Canvas c, Scene s) {
        float t = ((hour + minute / 60f) - 6f) / 12f; // 0 at 6am, 1 at 6pm
        if (t <= 0f || t >= 1f) {
            return;
        }
        float k = (0.5f - t) * 2f; // +1 morning ... -1 evening
        float strength = (float) Math.sin(Math.PI * t);
        int alpha = (int) (255f * 0.42f * Math.sqrt(strength));
        matrix.setScale(s.cell, s.cell);
        matrix.postSkew(-k * 0.10f, 0f, s.shadowPivotX, s.shadowPivotY);
        matrix.postTranslate(k * width * 0.06f, height * 0.01f);
        bitmapPaint.setAlpha(alpha);
        c.drawBitmap(s.shadow, matrix, bitmapPaint);
        bitmapPaint.setAlpha(255);
    }

    // ---------- clock ----------

    private void layout() {
        layoutDirty = false;
        ringDirty = true;
        Scene s = scene;

        float base;
        if (manualX >= 0f && manualY >= 0f) {
            cx = manualX * width;
            cy = manualY * height;
            base = width * 0.27f;
        } else if (s != null) {
            cx = s.autoX;
            cy = s.autoY;
            base = s.autoR;
        } else {
            cx = width / 2f;
            cy = height * 0.34f;
            base = width * 0.30f;
        }
        radius = Math.max(width * 0.08f, Math.min(width * 0.46f, base * sizePercent / 100f));

        hand(hourPath, radius * 0.52f, radius * 0.034f, radius * 0.020f, radius * 0.09f);
        hand(minutePath, radius * 0.80f, radius * 0.024f, radius * 0.012f, radius * 0.11f);

        // Each tick picks black or white from the photo behind it, so it is always readable.
        Bitmap bg = s != null ? s.background : null;
        float sum = 0f;
        for (int i = 0; i < TICKS; i++) {
            float lum = 0f;
            if (bg != null) {
                float acc = 0f;
                int n = 0;
                for (int q = 0; q < 3; q++) {
                    float rr = radius * (0.84f + 0.07f * q);
                    int px = Math.round(cx + COS[i] * rr);
                    int py = Math.round(cy + SIN[i] * rr);
                    if (px >= 0 && py >= 0 && px < bg.getWidth() && py < bg.getHeight()) {
                        int p = bg.getPixel(px, py);
                        acc += 0.299f * ((p >> 16) & 0xFF) + 0.587f * ((p >> 8) & 0xFF) + 0.114f * (p & 0xFF);
                        n++;
                    }
                }
                lum = n > 0 ? acc / n : 0f;
            }
            tickDark[i] = lum > 150f;
            sum += lum;
        }
        handsDark = sum / TICKS > 140f;
    }

    private static void hand(Path p, float len, float baseHalf, float tipHalf, float tail) {
        p.rewind();
        p.moveTo(-baseHalf, tail);
        p.lineTo(-tipHalf, -len);
        p.lineTo(tipHalf, -len);
        p.lineTo(baseHalf, tail);
        p.close();
    }

    private static int argb(int color, int alpha) {
        return (color & 0x00FFFFFF) | (alpha << 24);
    }

    /**
     * The static ring is drawn once into a bitmap. It is rebuilt only when the layout or the
     * battery level changes. Lit ticks show the battery level: 65% lights 39 of the 60 ticks.
     */
    private void buildRing() {
        ringDirty = false;
        boolean br = (fx & Settings.FX_BATTERY) != 0;
        int lit = br ? Math.max(1, Math.round(batteryPct * 60f / 100f)) : TICKS;

        int size = (int) Math.ceil(radius * 2.2f) + 4;
        if (ring != null && ring.getWidth() != size) {
            ring.recycle();
            ring = null;
        }
        if (ring == null) {
            ring = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        } else {
            ring.eraseColor(Color.TRANSPARENT);
        }
        Canvas cv = new Canvas(ring);
        float c0 = size / 2f;

        for (int i = 0; i < TICKS; i++) {
            boolean hr = i % 5 == 0;
            boolean isLit = !br || i < lit;
            float rin = radius * (hr ? 0.80f : 0.89f);
            if (br && isLit) {
                rin -= radius * 0.03f;
            }
            float rout = radius * 0.97f;
            float w = radius * (hr ? 0.028f : 0.013f);
            int a = isLit ? 255 : 70;
            int ink = tickDark[i] ? 0xFF16161A : 0xFFF7F7FA;
            int edge = tickDark[i] ? 0xFFFFFFFF : 0xFF000000;

            float x1 = c0 + COS[i] * rin;
            float y1 = c0 + SIN[i] * rin;
            float x2 = c0 + COS[i] * rout;
            float y2 = c0 + SIN[i] * rout;

            line.setStrokeWidth(w + radius * 0.012f);
            line.setColor(argb(edge, a * 110 / 255));
            cv.drawLine(x1, y1, x2, y2, line);
            line.setStrokeWidth(w);
            line.setColor(argb(ink, a));
            cv.drawLine(x1, y1, x2, y2, line);
        }
    }

    private void drawClock(Canvas c, boolean sweep) {
        if (ringDirty || ring == null) {
            buildRing();
        }
        c.drawBitmap(ring, cx - ring.getWidth() / 2f, cy - ring.getHeight() / 2f, bitmapPaint);

        float head = sweep ? sec + ms / 1000f : sec;

        // Light-painting trail: recent seconds glow red and fade away.
        for (int t = 0; t < TRAIL; t++) {
            float d = head - (sec - t);
            float in = 1f - d / TRAIL;
            if (in <= 0f) {
                continue;
            }
            in *= in;
            int i = ((sec - t) % 60 + 60) % 60;
            boolean hr = i % 5 == 0;
            float rin = radius * (hr ? 0.80f : 0.89f) - radius * 0.035f * in;
            float rout = radius * 0.97f;
            float w = radius * (hr ? 0.028f : 0.014f);
            float x1 = cx + COS[i] * rin;
            float y1 = cy + SIN[i] * rin;
            float x2 = cx + COS[i] * rout;
            float y2 = cy + SIN[i] * rout;
            line.setColor(argb(RED, (int) (70f * in)));
            line.setStrokeWidth(w * 3.4f);
            c.drawLine(x1, y1, x2, y2, line);
            line.setColor(argb(RED, (int) (255f * in)));
            line.setStrokeWidth(w * (1f + 0.6f * in));
            c.drawLine(x1, y1, x2, y2, line);
        }

        float hourDeg = ((hour % 12) + minute / 60f + sec / 3600f) * 30f;
        float minuteDeg = (minute + (sec + (sweep ? ms / 1000f : 0f)) / 60f) * 6f;
        float secondDeg = head * 6f;
        int ink = handsDark ? 0xFF16161A : 0xFFF7F7FA;
        int edge = handsDark ? 0xCCFFFFFF : 0xCC000000;

        // Hour then minute: each later hand carries an outline, so overlaps stay clean.
        drawHand(c, hourPath, hourDeg, ink, edge, radius * 0.026f);
        drawHand(c, minutePath, minuteDeg, ink, edge, radius * 0.022f);

        c.save();
        c.translate(cx, cy);
        c.rotate(secondDeg);
        line.setColor(argb(edge, 120));
        line.setStrokeWidth(radius * 0.018f);
        c.drawLine(0f, radius * 0.16f, 0f, -radius * 0.88f, line);
        line.setColor(RED);
        line.setStrokeWidth(radius * 0.007f);
        c.drawLine(0f, radius * 0.16f, 0f, -radius * 0.88f, line);
        c.restore();

        fill.setColor(edge);
        c.drawCircle(cx, cy, radius * 0.062f, fill);
        fill.setColor(ink);
        c.drawCircle(cx, cy, radius * 0.05f, fill);
        fill.setColor(RED);
        c.drawCircle(cx, cy, radius * 0.018f, fill);
    }

    private void drawHand(Canvas c, Path p, float deg, int ink, int edge, float outlineWidth) {
        c.save();
        c.translate(cx, cy);
        c.rotate(deg);
        outline.setStrokeWidth(outlineWidth);
        outline.setColor(edge);
        c.drawPath(p, outline);
        fill.setColor(ink);
        c.drawPath(p, fill);
        c.restore();
    }

    // ---------- comet ----------

    /** A bright comet circles the subject's outline once a minute and leaves a long fading trail. */
    private void drawComet(Canvas c, Scene s) {
        int m = s.segCount;
        if (m < 40) {
            return;
        }
        float[] segs = s.segs;
        float base = Math.max(2.2f, width * 0.0034f);

        line.setStrokeWidth(Math.max(1.5f, width * 0.0016f));
        line.setColor(0x30FFFFFF);
        c.drawLines(segs, 0, m * 4, line);

        float frac = (sec + ms / 1000f) / 60f;
        int head = (int) (frac * m) % m;
        int len = Math.min(m - 1, Math.max(12, (int) (m * 0.26f)));
        final int k = 12;

        for (int i = 0; i < k; i++) {
            float t = (i + 1f) / k;
            float t2 = t * t;
            int a = head - len + (i * len) / k;
            int b = head - len + ((i + 1) * len) / k;
            int n = b - a + 1;
            line.setColor(Color.argb((int) (80f * t2), 255, 40, 60));
            line.setStrokeWidth(base * (1.6f + 3.2f * t));
            drawSegs(c, segs, m, a, n);
            line.setColor(Color.argb((int) (255f * t2), 255, 90, 70));
            line.setStrokeWidth(base * (0.35f + 0.65f * t));
            drawSegs(c, segs, m, a, n);
        }
        line.setColor(0xFFFFF1E6);
        line.setStrokeWidth(base * 1.25f);
        drawSegs(c, segs, m, head - 3, 4);
    }

    private void drawSegs(Canvas c, float[] segs, int m, int start, int n) {
        int s = ((start % m) + m) % m;
        if (s + n <= m) {
            c.drawLines(segs, s * 4, n * 4, line);
        } else {
            int first = m - s;
            c.drawLines(segs, s * 4, first * 4, line);
            c.drawLines(segs, 0, (n - first) * 4, line);
        }
    }

    // ---------- lenses ----------

    private void drawLens(Canvas c, float[] e, boolean sweep) {
        float hourDeg = ((hour % 12) + minute / 60f) * 30f;
        float minuteDeg = (minute + sec / 60f) * 6f;
        float secondDeg = (sec + (sweep ? ms / 1000f : 0f)) * 6f;
        for (int i = 0; i < 2; i++) {
            c.save();
            c.translate(e[i * 2], e[i * 2 + 1]);
            c.scale(e[4], e[4]);
            line.setColor(0x9CFFFFFF);
            line.setStrokeWidth(0.07f);
            c.drawLines(LENS_TICKS, 0, 48, line);

            line.setStrokeWidth(0.11f);
            c.save();
            c.rotate(hourDeg);
            c.drawLine(0f, 0f, 0f, -0.46f, line);
            c.restore();

            line.setStrokeWidth(0.07f);
            c.save();
            c.rotate(minuteDeg);
            c.drawLine(0f, 0f, 0f, -0.72f, line);
            c.restore();

            fill.setColor(0xE0E8283C);
            c.save();
            c.rotate(secondDeg);
            c.drawCircle(0f, -0.82f, 0.07f, fill);
            c.restore();
            c.restore();
        }
    }
}
