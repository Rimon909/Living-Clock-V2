package com.rimon.livingclock;

import android.content.Context;
import android.content.SharedPreferences;

/** Preferences shared by the wallpaper service and the studio screen. */
public final class Settings {

    public static final String PREFS = "living_clock";

    public static final String KEY_MODE = "power_mode";
    public static final String KEY_FX = "effects";
    public static final String KEY_SIZE = "clock_size";
    public static final String KEY_X = "clock_x";
    public static final String KEY_Y = "clock_y";
    public static final String KEY_SCENE = "scene_version";
    public static final String KEY_EYES = "eyes";

    /** ECO ticks once per second and sleeps in between. */
    public static final int MODE_ECO = 0;
    /** BALANCED animates at 30 fps. */
    public static final int MODE_BALANCED = 1;
    /** ULTRA animates at 60 fps. */
    public static final int MODE_ULTRA = 2;

    public static final int FX_COMET = 1;
    public static final int FX_FOCUS = 2;
    public static final int FX_SHADOW = 4;
    public static final int FX_LENS = 8;
    public static final int FX_BATTERY = 16;
    public static final int FX_ALL = 31;

    private Settings() {}

    public static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static int mode(Context c) {
        return prefs(c).getInt(KEY_MODE, MODE_BALANCED);
    }

    public static int fx(Context c) {
        return prefs(c).getInt(KEY_FX, FX_ALL);
    }

    public static int size(Context c) {
        return prefs(c).getInt(KEY_SIZE, 100);
    }

    /** Wakes the wallpaper and the preview so they rebuild their scene from the saved files. */
    public static void bumpScene(Context c) {
        SharedPreferences p = prefs(c);
        p.edit().putInt(KEY_SCENE, p.getInt(KEY_SCENE, 0) + 1).apply();
    }
}
