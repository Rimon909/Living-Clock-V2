package com.rimon.livingclock;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity {

    private static final int REQ_PHOTO = 101;
    private static final int REQ_CUTOUT = 102;

    private final int backgroundColor = Color.rgb(10, 14, 22);
    private final int cardColor = Color.rgb(24, 30, 42);
    private final int cardStroke = Color.rgb(44, 53, 69);
    private final int accentColor = Color.rgb(225, 48, 65);
    private final int secondaryText = Color.rgb(157, 169, 187);

    private final ArrayList<Button> chips = new ArrayList<>();
    private final ArrayList<Integer> chipBits = new ArrayList<>();

    private LinearLayout root;
    private LivingPreview preview;
    private TextView statusText;
    private TextView sizeLabel;
    private Button powerButton;
    private int screenW;
    private int screenH;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(backgroundColor);
        getWindow().setNavigationBarColor(backgroundColor);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        screenW = Math.min(dm.widthPixels, dm.heightPixels);
        screenH = Math.max(dm.widthPixels, dm.heightPixels);

        buildInterface();
    }

    @Override
    protected void onResume() {
        super.onResume();
        preview.setActive(true);
        refreshControls();
    }

    @Override
    protected void onPause() {
        preview.setActive(false);
        super.onPause();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        Uri uri = data.getData();
        if (requestCode == REQ_PHOTO) {
            toast("Cutting out your subject…");
            LayerLoader.importPhoto(this, uri, (ok, message) -> finishImport(message));
        } else if (requestCode == REQ_CUTOUT) {
            LayerLoader.importCutout(this, uri, (ok, message) -> finishImport(message));
        }
    }

    private void finishImport(String message) {
        toast(message);
        preview.reloadScene();
        refreshControls();
    }

    // ---------- layout ----------

    private void buildInterface() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(backgroundColor);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(20), dp(22), dp(28));
        scroll.addView(root);
        setContentView(scroll);

        addHeader();
        addPreview();
        addPhotoCard();
        addEffectsCard();
        addClockCard();
        addPowerCard();
        addApplyButton();

        TextView footer = text("DESIGNED FOR YOUR SCREEN  •  BUILT WITH CARE", 9, Color.rgb(104, 117, 137));
        footer.setGravity(Gravity.CENTER);
        footer.setLetterSpacing(0.07f);
        root.addView(footer, new LinearLayout.LayoutParams(-1, -2));
    }

    private void addHeader() {
        LinearLayout header = row();

        LinearLayout titleGroup = new LinearLayout(this);
        titleGroup.setOrientation(LinearLayout.VERTICAL);

        TextView eyebrow = text("PERSONAL WALLPAPER STUDIO", 10, Color.rgb(230, 92, 105));
        eyebrow.setLetterSpacing(0.12f);
        TextView title = text("LIVING CLOCK", 25, Color.WHITE);
        title.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        title.setLetterSpacing(0.035f);
        TextView subtitle = text("TIME, WITH DEPTH.", 11, secondaryText);
        subtitle.setLetterSpacing(0.17f);

        titleGroup.addView(eyebrow);
        titleGroup.addView(title);
        titleGroup.addView(subtitle);
        header.addView(titleGroup, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView badge = text("BETA", 10, Color.WHITE);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(12), dp(8), dp(12), dp(8));
        badge.setBackground(rounded(Color.rgb(45, 30, 43), Color.rgb(105, 51, 69), 18));
        header.addView(badge);
        root.addView(header);
        root.addView(new View(this), new LinearLayout.LayoutParams(1, dp(22)));
    }

    private void addPreview() {
        LinearLayout card = panel();

        LinearLayout head = row();
        TextView title = text("LIVE PREVIEW", 11, Color.WHITE);
        title.setTypeface(null, Typeface.BOLD);
        title.setLetterSpacing(0.12f);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(text("●  LIVE", 9, Color.rgb(244, 111, 124)));
        card.addView(head);

        int previewH = dp(430);
        int previewW = previewH * screenW / screenH;
        preview = new LivingPreview();
        preview.setBackground(rounded(backgroundColor, cardStroke, 18));
        preview.setClipToOutline(true);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(previewW, previewH);
        pp.topMargin = dp(10);
        pp.gravity = Gravity.CENTER_HORIZONTAL;
        card.addView(preview, pp);

        TextView caption = text("Drag on the preview to move the clock.", 11, secondaryText);
        caption.setGravity(Gravity.CENTER);
        caption.setPadding(0, dp(8), 0, 0);
        card.addView(caption, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.bottomMargin = dp(26);
        root.addView(card, cp);
    }

    private void addPhotoCard() {
        LinearLayout card = featureCard("01", "Photo Studio",
                "Pick one portrait. Your subject is cut out automatically, and the clock is placed in "
                        + "the free space behind you.");

        LinearLayout buttons = buttonRow(card);
        actionButton(buttons, "CHOOSE PHOTO", () -> pick(REQ_PHOTO));
        actionButton(buttons, "OWN CUTOUT PNG", () -> pick(REQ_CUTOUT));

        statusText = text("", 11, secondaryText);
        statusText.setPadding(0, dp(12), 0, 0);
        card.addView(statusText, new LinearLayout.LayoutParams(-1, -2));

        TextView clear = text("Remove photo", 11, secondaryText);
        clear.setPadding(0, dp(10), 0, 0);
        clear.setOnClickListener(v -> LayerLoader.clear(this, () -> {
            preview.reloadScene();
            refreshControls();
        }));
        card.addView(clear, new LinearLayout.LayoutParams(-1, -2));
    }

    private void addEffectsCard() {
        LinearLayout card = featureCard("02", "Living Effects",
                "A comet circles your outline, the background pulls focus every minute, a sun shadow "
                        + "follows the real hour, tiny clocks appear in your lenses, and the ticks "
                        + "light up to your battery level.");

        LinearLayout r1 = buttonRow(card);
        addChip(r1, "COMET", Settings.FX_COMET);
        addChip(r1, "FOCUS PULL", Settings.FX_FOCUS);
        LinearLayout r2 = buttonRow(card);
        addChip(r2, "SUN SHADOW", Settings.FX_SHADOW);
        addChip(r2, "LENS CLOCKS", Settings.FX_LENS);
        LinearLayout r3 = buttonRow(card);
        addChip(r3, "BATTERY RING", Settings.FX_BATTERY);
    }

    private void addClockCard() {
        LinearLayout card = featureCard("03", "Clock Placement",
                "Placed automatically. Drag the preview to override, or change the size.");

        sizeLabel = text("", 11, secondaryText);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        card.addView(sizeLabel, lp);

        SeekBar size = new SeekBar(this);
        size.setMax(100); // 50% to 150%
        size.setProgress(Settings.size(this) - 50);
        size.setProgressTintList(ColorStateList.valueOf(accentColor));
        size.setThumbTintList(ColorStateList.valueOf(accentColor));
        size.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                sizeLabel.setText("SIZE  " + (50 + progress) + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                Settings.prefs(MainActivity.this).edit()
                        .putInt(Settings.KEY_SIZE, 50 + bar.getProgress()).apply();
                preview.applySettings();
            }
        });
        card.addView(size, new LinearLayout.LayoutParams(-1, -2));

        actionButton(buttonRow(card), "AUTO PLACE", () -> {
            Settings.prefs(this).edit()
                    .putFloat(Settings.KEY_X, -1f)
                    .putFloat(Settings.KEY_Y, -1f)
                    .apply();
            preview.applySettings();
        });
    }

    private void addPowerCard() {
        LinearLayout card = featureCard("04", "Power",
                "ECO ticks once per second and sleeps in between. BALANCED animates at 30 fps. "
                        + "ULTRA runs at 60 fps. Battery saver or 15% battery switches to ECO by itself.");
        powerButton = actionButton(buttonRow(card), "", () -> {
            int next = (Settings.mode(this) + 1) % 3;
            Settings.prefs(this).edit().putInt(Settings.KEY_MODE, next).apply();
            preview.applySettings();
            refreshControls();
        });
    }

    private void addApplyButton() {
        Button apply = new Button(this);
        apply.setText("APPLY WALLPAPER   →");
        apply.setTextColor(Color.WHITE);
        apply.setTextSize(13);
        apply.setTypeface(null, Typeface.BOLD);
        apply.setAllCaps(false);
        apply.setLetterSpacing(0.04f);
        apply.setElevation(dp(5));
        apply.setBackground(rounded(accentColor, Color.rgb(255, 111, 126), 17));
        apply.setOnClickListener(v -> openWallpaperPicker());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(56));
        p.topMargin = dp(16);
        p.bottomMargin = dp(16);
        root.addView(apply, p);
    }

    private LinearLayout featureCard(String number, String title, String description) {
        LinearLayout card = panel();

        LinearLayout top = row();
        TextView index = text(number, 11, accentColor);
        index.setTypeface(null, Typeface.BOLD);
        TextView heading = text("  " + title, 17, Color.WHITE);
        heading.setTypeface(null, Typeface.BOLD);
        top.addView(index);
        top.addView(heading, new LinearLayout.LayoutParams(0, -2, 1f));
        card.addView(top);

        TextView detail = text(description, 12, secondaryText);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-1, -2);
        dlp.topMargin = dp(7);
        card.addView(detail, dlp);

        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.bottomMargin = dp(12);
        root.addView(card, cp);
        return card;
    }

    private LinearLayout buttonRow(LinearLayout card) {
        LinearLayout buttons = row();
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(10);
        card.addView(buttons, p);
        return buttons;
    }

    private Button actionButton(LinearLayout row, String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(10);
        b.setTextColor(Color.WHITE);
        b.setLetterSpacing(0.06f);
        b.setPadding(dp(10), 0, dp(10), 0);
        b.setBackground(rounded(Color.rgb(37, 44, 59), Color.rgb(69, 80, 101), 12));
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1f);
        if (row.getChildCount() > 0) {
            p.leftMargin = dp(8);
        }
        row.addView(b, p);
        return b;
    }

    private void addChip(LinearLayout row, String label, int bit) {
        Button b = actionButton(row, label, () -> {
            int fx = Settings.fx(this) ^ bit;
            Settings.prefs(this).edit().putInt(Settings.KEY_FX, fx).apply();
            preview.applySettings();
            refreshControls();
        });
        chips.add(b);
        chipBits.add(bit);
    }

    // ---------- actions ----------

    private void pick(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(intent, requestCode);
        } catch (ActivityNotFoundException e) {
            toast("No photo app available.");
        }
    }

    private void refreshControls() {
        int fx = Settings.fx(this);
        for (int i = 0; i < chips.size(); i++) {
            boolean on = (fx & chipBits.get(i)) != 0;
            Button b = chips.get(i);
            b.setBackground(on
                    ? rounded(Color.rgb(110, 28, 42), accentColor, 12)
                    : rounded(Color.rgb(37, 44, 59), Color.rgb(69, 80, 101), 12));
        }
        sizeLabel.setText("SIZE  " + Settings.size(this) + "%");

        int mode = Settings.mode(this);
        powerButton.setText(mode == Settings.MODE_ECO ? "POWER · ECO  1 FPS TICK"
                : mode == Settings.MODE_ULTRA ? "POWER · ULTRA  60 FPS"
                : "POWER · BALANCED  30 FPS");

        if (!LayerLoader.hasPhoto(this)) {
            statusText.setText("No photo yet. Choose one to begin.");
        } else {
            statusText.setText("Photo ✓     Cutout " + (LayerLoader.hasMask(this) ? "✓" : "✗")
                    + "     Lens clocks " + (LayerLoader.hasEyes(this) ? "✓" : "✗"));
        }
    }

    private void openWallpaperPicker() {
        try {
            Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
            intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    new ComponentName(this, LivingClockService.class));
            startActivity(intent);
        } catch (Exception e) {
            toast("Couldn't open the wallpaper preview.");
        }
    }

    // ---------- view helpers ----------

    private LinearLayout panel() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(17), dp(15), dp(17), dp(15));
        card.setBackground(rounded(cardColor, cardStroke, 20));
        return card;
    }

    private LinearLayout row() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    private TextView text(String value, int size, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        return view;
    }

    private GradientDrawable rounded(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    // ---------- live preview ----------

    /**
     * Uses the same renderer and scene as the wallpaper, at the phone's own aspect ratio, so
     * what you see here is what the wallpaper draws. Animates only while the app is open.
     */
    private final class LivingPreview extends View {

        private final ClockRenderer renderer = new ClockRenderer();
        private Scene scene;
        private boolean active;
        private int mode = Settings.MODE_BALANCED;
        private int generation;
        private float dragX = -1f;
        private float dragY = -1f;

        LivingPreview() {
            super(MainActivity.this);
            applySettings();
        }

        void applySettings() {
            Context c = getContext();
            mode = Settings.mode(c);
            renderer.setOptions(Settings.fx(c), Settings.size(c),
                    Settings.prefs(c).getFloat(Settings.KEY_X, -1f),
                    Settings.prefs(c).getFloat(Settings.KEY_Y, -1f));
            invalidate();
        }

        void setActive(boolean value) {
            active = value;
            if (active) {
                Intent i = getContext().registerReceiver(null,
                        new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                if (i != null) {
                    int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                    if (level >= 0 && scale > 0) {
                        renderer.setBattery(level * 100 / scale);
                    }
                }
                applySettings();
            }
        }

        void reloadScene() {
            if (getWidth() <= 0 || getHeight() <= 0) {
                return;
            }
            final int gen = ++generation;
            Scene.buildAsync(getContext(), getWidth(), getHeight(), built -> {
                if (gen != generation) {
                    built.recycle();
                    return;
                }
                Scene old = scene;
                scene = built;
                renderer.setScene(built);
                if (old != null) {
                    old.recycle();
                }
                invalidate();
            });
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldW, int oldH) {
            super.onSizeChanged(w, h, oldW, oldH);
            renderer.setSize(w, h);
            if (scene != null) {
                scene.recycle();
                scene = null;
            }
            reloadScene();
        }

        @Override
        protected void onDetachedFromWindow() {
            generation++;
            renderer.release();
            if (scene != null) {
                scene.recycle();
                scene = null;
            }
            super.onDetachedFromWindow();
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE) {
                if (getParent() != null) {
                    getParent().requestDisallowInterceptTouchEvent(true);
                }
                dragX = Math.max(0f, Math.min(1f, e.getX() / getWidth()));
                dragY = Math.max(0f, Math.min(1f, e.getY() / getHeight()));
                Context c = getContext();
                renderer.setOptions(Settings.fx(c), Settings.size(c), dragX, dragY);
                invalidate();
                return true;
            }
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                if (dragX >= 0f) {
                    Settings.prefs(getContext()).edit()
                            .putFloat(Settings.KEY_X, dragX)
                            .putFloat(Settings.KEY_Y, dragY)
                            .apply();
                }
                return true;
            }
            return super.onTouchEvent(e);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            long now = System.currentTimeMillis();
            renderer.draw(canvas, now, mode != Settings.MODE_ECO);
            if (!active) {
                return;
            }
            int fps = renderer.targetFps(now, mode);
            if (fps >= 60) {
                postInvalidateOnAnimation();
            } else if (fps > 1) {
                postInvalidateDelayed(1000L / fps);
            } else {
                postInvalidateDelayed(1000L - (now % 1000L) + 4L);
            }
        }
    }
}
