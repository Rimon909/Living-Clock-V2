package com.rimon.livingclock;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import com.google.mlkit.vision.face.FaceLandmark;
import com.google.mlkit.vision.segmentation.Segmentation;
import com.google.mlkit.vision.segmentation.SegmentationMask;
import com.google.mlkit.vision.segmentation.Segmenter;
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * One-time import work, done in the studio app and never in the wallpaper service.
 * Saves three small things: the oriented photo, a person mask, and the eye positions.
 * Everything the wallpaper draws is derived from those files by Scene.
 */
public final class LayerLoader {

    public static final String PHOTO_FILE = "photo.jpg";
    public static final String MASK_FILE = "mask.png";

    private static final int WORK_SIDE = 2048;
    private static final int ML_SIDE = 768;

    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    public interface Callback {
        void done(boolean ok, String message);
    }

    private LayerLoader() {}

    // ---------- public API ----------

    /** Imports a photo, cuts out the person and finds the eyes. */
    public static void importPhoto(Context context, Uri uri, Callback cb) {
        Context app = context.getApplicationContext();
        IO.execute(() -> {
            boolean ok;
            String msg;
            try {
                msg = doImportPhoto(app, uri);
                ok = true;
            } catch (Throwable t) {
                ok = false;
                msg = "Couldn't import that photo.";
            }
            post(cb, ok, msg);
        });
    }

    /** Uses the alpha channel of a transparent PNG of the same photo as the subject mask. */
    public static void importCutout(Context context, Uri uri, Callback cb) {
        Context app = context.getApplicationContext();
        IO.execute(() -> {
            boolean ok;
            String msg;
            try {
                msg = doImportCutout(app, uri);
                ok = true;
            } catch (Throwable t) {
                ok = false;
                msg = t.getMessage() != null && t.getMessage().startsWith("!")
                        ? t.getMessage().substring(1)
                        : "Couldn't use that PNG.";
            }
            post(cb, ok, msg);
        });
    }

    public static void clear(Context context, Runnable onDone) {
        Context app = context.getApplicationContext();
        IO.execute(() -> {
            new File(app.getFilesDir(), PHOTO_FILE).delete();
            new File(app.getFilesDir(), MASK_FILE).delete();
            Settings.prefs(app).edit().remove(Settings.KEY_EYES).apply();
            Settings.bumpScene(app);
            MAIN.post(onDone);
        });
    }

    public static boolean hasPhoto(Context c) {
        return new File(c.getFilesDir(), PHOTO_FILE).exists();
    }

    public static boolean hasMask(Context c) {
        return new File(c.getFilesDir(), MASK_FILE).exists();
    }

    public static boolean hasEyes(Context c) {
        String e = Settings.prefs(c).getString(Settings.KEY_EYES, "");
        return e != null && !e.isEmpty();
    }

    private static void post(Callback cb, boolean ok, String msg) {
        MAIN.post(() -> cb.done(ok, msg));
    }

    // ---------- import steps ----------

    private static String doImportPhoto(Context app, Uri uri) throws Exception {
        File tmp = new File(app.getCacheDir(), "import.tmp");
        copy(app, uri, tmp);
        Bitmap photo = decodeOriented(tmp, WORK_SIDE);
        tmp.delete();
        if (photo == null) {
            throw new IOException("decode failed");
        }

        // A new photo invalidates the old mask and eyes.
        new File(app.getFilesDir(), MASK_FILE).delete();
        try (OutputStream os = new FileOutputStream(new File(app.getFilesDir(), PHOTO_FILE))) {
            photo.compress(Bitmap.CompressFormat.JPEG, 93, os);
        }

        Bitmap small = scaleToSide(photo, ML_SIDE);
        boolean mask = false;
        String eyes = "";

        try {
            Bitmap m = segment(small);
            if (m != null) {
                try (OutputStream os = new FileOutputStream(new File(app.getFilesDir(), MASK_FILE))) {
                    m.compress(Bitmap.CompressFormat.PNG, 100, os);
                }
                m.recycle();
                mask = true;
            }
        } catch (Throwable ignored) {
            // Cutout is optional. The wallpaper still works with the photo alone.
        }

        try {
            float[] e = findEyes(small);
            if (e != null) {
                eyes = e[0] + "," + e[1] + "," + e[2] + "," + e[3] + "," + e[4];
            }
        } catch (Throwable ignored) {
            // Lens clocks are optional.
        }

        if (small != photo) {
            small.recycle();
        }
        photo.recycle();

        SharedPreferences p = Settings.prefs(app);
        p.edit()
                .putString(Settings.KEY_EYES, eyes)
                .putFloat(Settings.KEY_X, -1f)
                .putFloat(Settings.KEY_Y, -1f)
                .putInt(Settings.KEY_SCENE, p.getInt(Settings.KEY_SCENE, 0) + 1)
                .apply();

        if (!mask) {
            return "Photo set, but no person was found. Try your own cutout PNG.";
        }
        return eyes.isEmpty()
                ? "Subject cut out. Eyes not found, so lens clocks are off."
                : "Subject cut out and eyes found.";
    }

    private static String doImportCutout(Context app, Uri uri) throws Exception {
        if (!hasPhoto(app)) {
            throw new IOException("!Choose a photo first.");
        }
        File tmp = new File(app.getCacheDir(), "cutout.tmp");
        copy(app, uri, tmp);
        Bitmap src = decodeOriented(tmp, 1024);
        tmp.delete();
        if (src == null) {
            throw new IOException("decode failed");
        }

        Bitmap alpha = src.extractAlpha();
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Paint black = new Paint();
        black.setColor(Color.BLACK);
        new Canvas(out).drawBitmap(alpha, 0f, 0f, black);
        src.recycle();
        alpha.recycle();

        int n = out.getWidth() * out.getHeight();
        int[] px = new int[n];
        out.getPixels(px, 0, out.getWidth(), 0, 0, out.getWidth(), out.getHeight());
        int covered = 0;
        for (int i = 0; i < n; i += 7) {
            if ((px[i] >>> 24) > 127) {
                covered++;
            }
        }
        float cov = covered / (n / 7f);
        if (cov < 0.02f || cov > 0.97f) {
            out.recycle();
            throw new IOException("!That PNG has no transparent background.");
        }

        try (OutputStream os = new FileOutputStream(new File(app.getFilesDir(), MASK_FILE))) {
            out.compress(Bitmap.CompressFormat.PNG, 100, os);
        }
        out.recycle();
        Settings.bumpScene(app);
        return "Cutout applied.";
    }

    // ---------- ML Kit ----------

    /** Returns a black bitmap whose alpha channel is the person mask, or null if no person is found. */
    private static Bitmap segment(Bitmap small) throws Exception {
        SelfieSegmenterOptions opts = new SelfieSegmenterOptions.Builder()
                .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
                .build();
        Segmenter segmenter = Segmentation.getClient(opts);
        try {
            SegmentationMask mask = Tasks.await(segmenter.process(InputImage.fromBitmap(small, 0)));
            int mw = mask.getWidth();
            int mh = mask.getHeight();
            ByteBuffer buf = mask.getBuffer();
            buf.rewind();
            FloatBuffer fb = buf.asFloatBuffer();

            int n = mw * mh;
            int[] px = new int[n];
            int covered = 0;
            for (int i = 0; i < n; i++) {
                // Contrast curve: removes grey half-transparent patches inside the body.
                float t = (fb.get() - 0.30f) / 0.45f;
                t = t < 0f ? 0f : (t > 1f ? 1f : t);
                t = t * t * (3f - 2f * t);
                int a = (int) (t * 255f + 0.5f);
                if (a > 127) {
                    covered++;
                }
                px[i] = a << 24;
            }
            float cov = covered / (float) n;
            if (cov < 0.02f || cov > 0.97f) {
                return null;
            }
            Bitmap out = Bitmap.createBitmap(mw, mh, Bitmap.Config.ARGB_8888);
            out.setPixels(px, 0, mw, 0, 0, mw, mh);
            return out;
        } finally {
            segmenter.close();
        }
    }

    /** Returns {leftX, leftY, rightX, rightY, lensRadius}, all normalised to the image width/height. */
    private static float[] findEyes(Bitmap small) throws Exception {
        FaceDetectorOptions opts = new FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                .build();
        FaceDetector detector = FaceDetection.getClient(opts);
        try {
            List<Face> faces = Tasks.await(detector.process(InputImage.fromBitmap(small, 0)));
            Face best = null;
            long bestArea = 0L;
            for (Face f : faces) {
                long area = (long) f.getBoundingBox().width() * f.getBoundingBox().height();
                if (area > bestArea) {
                    bestArea = area;
                    best = f;
                }
            }
            if (best == null) {
                return null;
            }
            FaceLandmark l = best.getLandmark(FaceLandmark.LEFT_EYE);
            FaceLandmark r = best.getLandmark(FaceLandmark.RIGHT_EYE);
            if (l == null || r == null) {
                return null;
            }
            PointF a = l.getPosition();
            PointF b = r.getPosition();
            float dist = (float) Math.hypot(a.x - b.x, a.y - b.y);
            float radius = Math.max(dist * 0.36f, best.getBoundingBox().width() * 0.07f);
            float sw = small.getWidth();
            float sh = small.getHeight();
            return new float[]{a.x / sw, a.y / sh, b.x / sw, b.y / sh, radius / sw};
        } finally {
            detector.close();
        }
    }

    // ---------- image helpers ----------

    private static void copy(Context app, Uri uri, File dest) throws IOException {
        try (InputStream in = app.getContentResolver().openInputStream(uri);
             OutputStream os = new FileOutputStream(dest)) {
            if (in == null) {
                throw new IOException("cannot open");
            }
            byte[] buffer = new byte[64 * 1024];
            int n;
            while ((n = in.read(buffer)) != -1) {
                os.write(buffer, 0, n);
            }
        }
    }

    private static Bitmap decodeOriented(File file, int maxSide) {
        String path = file.getAbsolutePath();
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            return null;
        }
        int sample = 1;
        while (Math.max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) {
            sample *= 2;
        }
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap bm = BitmapFactory.decodeFile(path, opts);
        if (bm == null) {
            return null;
        }
        int rotation = exifRotation(file);
        if (rotation != 0) {
            Matrix m = new Matrix();
            m.postRotate(rotation);
            Bitmap rotated = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), m, true);
            if (rotated != bm) {
                bm.recycle();
            }
            bm = rotated;
        }
        Bitmap scaled = scaleToSide(bm, maxSide);
        if (scaled != bm) {
            bm.recycle();
        }
        return scaled;
    }

    /** Returns src itself when it is already small enough. The caller decides what to recycle. */
    private static Bitmap scaleToSide(Bitmap src, int side) {
        int longest = Math.max(src.getWidth(), src.getHeight());
        if (longest <= side) {
            return src;
        }
        float s = side / (float) longest;
        return Bitmap.createScaledBitmap(src,
                Math.max(1, Math.round(src.getWidth() * s)),
                Math.max(1, Math.round(src.getHeight() * s)), true);
    }

    private static int exifRotation(File file) {
        try {
            ExifInterface exif = new ExifInterface(file.getAbsolutePath());
            int o = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            if (o == ExifInterface.ORIENTATION_ROTATE_90) {
                return 90;
            }
            if (o == ExifInterface.ORIENTATION_ROTATE_180) {
                return 180;
            }
            if (o == ExifInterface.ORIENTATION_ROTATE_270) {
                return 270;
            }
        } catch (Exception ignored) {
            // No EXIF data: assume upright.
        }
        return 0;
    }
}
