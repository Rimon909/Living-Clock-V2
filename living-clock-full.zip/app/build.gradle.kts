plugins {
    id("com.android.application")
}

android {
    namespace = "com.rimon.livingclock"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.rimon.livingclock"
        minSdk = 23
        targetSdk = 34

        versionCode = 3
        versionName = "2.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // On-device subject cutout (about +4.5 MB) and eye finder for the lens clocks (about +6.9 MB).
    implementation("com.google.mlkit:segmentation-selfie:16.0.0-beta6")
    implementation("com.google.mlkit:face-detection:16.1.7")
    implementation("com.google.android.gms:play-services-tasks:18.2.0")
}
